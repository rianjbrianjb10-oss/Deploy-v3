
export default function Home() {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh',
      backgroundColor: '#0a0a0f',
      color: '#00fff7',
      fontFamily: 'Orbitron, sans-serif',
      fontSize: '3rem',
      textShadow: '0 0 20px #00fff7',
      flexDirection: 'column'
    }}>
      <h1 style={{ animation: 'glow 1.5s ease-in-out infinite alternate' }}>Welcome to YannDev</h1>
      <style jsx>{`
        @keyframes glow {
          from { text-shadow: 0 0 10px #00fff7, 0 0 20px #00fff7, 0 0 30px #00b3b3; }
          to { text-shadow: 0 0 20px #00fff7, 0 0 30px #00ffff, 0 0 40px #00ffff; }
        }
      `}</style>
    </div>
  );
}
